package com.mobileaiautomation.tests;

import com.mobileaiautomation.config.TestConfig;
import com.mobileaiautomation.driver.DriverFactory;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public abstract class BaseTest {
    protected TestConfig config;
    protected AndroidDriver driver;

    @BeforeMethod(alwaysRun = true)
    public void setUp() {
        config = new TestConfig();
        driver = DriverFactory.create(config);
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown(ITestResult result) {
        RuntimeException screenshotFailure = null;
        try {
            if (!result.isSuccess() && driver != null) {
                captureFailureScreenshot(result.getName());
            }
        } catch (IOException | RuntimeException e) {
            screenshotFailure = new RuntimeException("Unable to capture failure screenshot", e);
            Reporter.log(screenshotFailure.getMessage() + ": " + e.getMessage(), true);
        } finally {
            if (driver != null) {
                driver.quit();
                driver = null;
            }
        }
        if (screenshotFailure != null) {
            throw screenshotFailure;
        }
    }

    private void captureFailureScreenshot(String testName) throws IOException {
        Path screenshotDirectory = Path.of("target", "screenshots");
        Files.createDirectories(screenshotDirectory);
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss-SSS"));
        Path destination = screenshotDirectory.resolve(testName + "-" + timestamp + ".png");
        Path source = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE).toPath();
        Files.copy(source, destination, StandardCopyOption.REPLACE_EXISTING);
        Reporter.log("Failure screenshot: " + destination.toAbsolutePath(), true);
    }
}
